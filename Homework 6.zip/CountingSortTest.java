/**

 JUnit test class for CountingSort class.
 */
import org.junit.Test;
import static org.junit.Assert.assertArrayEquals;
public class CountingSortTest {
    /**
     * Tests the sort() method of CountingSort class with an array of non-negative integers.
     * Verifies that the sorted array matches the expected result.
     */
    @Test
    public void testSort() {
        int[] A = {2, 5, 3, 0, 2, 3, 0, 3};
        int[] expected = {0, 0, 2, 2, 3, 3, 3, 5};
        CountingSort.sort(A);
        assertArrayEquals(expected, A);
    }

    /**
     * Tests the sort() method of CountingSort class with an array of non-negative integers with duplicates.
     * Verifies that the sorted array matches the expected result.
     */
    @Test
    public void testSortWithDuplicates() {
        int[] A = {2, 5, 3, 0, 2, 3, 0, 3, 5};
        int[] expected = {0, 0, 2, 2, 3, 3, 3, 5, 5};
        CountingSort.sort(A);
        assertArrayEquals(expected, A);
    }

    /**
     * Tests the sort() method of CountingSort class with an array of integers, some of which are negative.
     * Verifies that the sorted array matches the expected result.
     */
    @Test
    public void testSortWithNegativeNumbers() {
        int[] A = {-2, 5, 3, 0, -2, 3, 0, 3};
        int[] expected = {-2, -2, 0, 0, 3, 3, 3, 5};
        CountingSort.sort(A);
        assertArrayEquals(expected, A);
    }

}