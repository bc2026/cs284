/**
 @author: Bhagawat Chapagain
 @pledge: I pledge my honor that I have abided by the Stevens Honor System.
 CountingSort class provides a static method for sorting an array of integers in ascending order using the counting sort algorithm.
 */
public class CountingSort {

    /**

     Sorts an array of integers in ascending order using the counting sort algorithm.

     @param A the array of integers to be sorted
     */
    public static void sort(int[] A) {
        int n = A.length;
        int k = getMax(A);
        int min = getMin(A);
        int[] C = new int[k - min + 1];
        int[] B = new int[n];

// Count the frequency of each element in A
        for (int i = 0; i < n; i++) {
            C[A[i] - min]++;
        }

// Calculate the cumulative frequency of each element in C
        for (int i = 1; i < C.length; i++) {
            C[i] += C[i - 1];
        }

// Place each element in its correct sorted position in B
        for (int i = n - 1; i >= 0; i--) {
            B[C[A[i] - min] - 1] = A[i];
            C[A[i] - min]--;
        }

// Copy the sorted array B back into A
        for (int i = 0; i < n; i++) {
            A[i] = B[i];
        }
    }

    /**

     Returns the maximum element in an array of integers.
     @param A the array of integers to find the maximum element from
     @return the maximum element in the array
     */
    private static int getMax(int[] A) {
        int max = A[0];
        for (int i = 1; i < A.length; i++) {
            if (A[i] > max) {
                max = A[i];
            }
        }
        return max;
    }
    /**

     Returns the minimum element in an array of integers.
     @param A the array of integers to find the minimum element from
     @return the minimum element in the array
     */
    private static int getMin(int[] A) {
        int min = A[0];
        for (int i = 1; i < A.length; i++) {
            if (A[i] < min) {
                min = A[i];
            }
        }
        return min;
    }
}